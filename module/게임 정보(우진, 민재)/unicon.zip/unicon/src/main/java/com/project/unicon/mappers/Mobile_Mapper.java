package com.project.unicon.mappers;

public class Mobile_Mapper {

}
