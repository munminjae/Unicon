package com.project.unicon.info.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.project.unicon.vo.Info_VO;

public interface Info_Service {
	public List<Info_VO> gameList() throws DataAccessException;
	public List<Info_VO> pcgameList() throws DataAccessException;
	public List<Info_VO> mobilegameList() throws DataAccessException;
	public List<Info_VO> xboxgameList() throws DataAccessException;
	public List<Info_VO> psgameList() throws DataAccessException;
	public List<Info_VO> nintendogameList() throws DataAccessException;
	public List<Info_VO> gamesearch(String searchValue, String genre) throws DataAccessException;
	public Info_VO gameview(int game_code) throws DataAccessException;
}