package com.project.unicon.info.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.project.unicon.mappers.Info_Mapper;
import com.project.unicon.vo.Info_VO;

@Service("info_Service")
@Transactional(propagation = Propagation.REQUIRED)
public class Info_ServiceImpl implements Info_Service {
	
	@Autowired
	private Info_Mapper info_Mapper;
	
	@Override
	public List<Info_VO> gameList() throws DataAccessException {
		List<Info_VO> gameList;
		gameList = info_Mapper.allgamelist();
		return gameList;
	}
	
	@Override
	public List<Info_VO> pcgameList() throws DataAccessException {
		List<Info_VO> pcgameList;
		pcgameList = info_Mapper.pcgamelist();
		return pcgameList;
	}
	
	@Override
	public List<Info_VO> mobilegameList() throws DataAccessException {
		List<Info_VO> mobilegameList;
		mobilegameList = info_Mapper.mobilegamelist();
		return mobilegameList;
	}
	
	@Override
	public List<Info_VO> xboxgameList() throws DataAccessException {
		List<Info_VO> xboxgameList;
		xboxgameList = info_Mapper.xboxgamelist();
		return xboxgameList;
	}
	
	@Override
	public List<Info_VO> psgameList() throws DataAccessException {
		List<Info_VO> psgameList;
		psgameList = info_Mapper.psgamelist();
		return psgameList;
	}
	
	@Override
	public List<Info_VO> nintendogameList() throws DataAccessException {
		List<Info_VO> nintendogameList;
		nintendogameList = info_Mapper.nintendogamelist();
		return nintendogameList;
	}
	
	@Override
	public Info_VO gameview(int game_code) throws DataAccessException {
		Info_VO info_VO = null;
		info_VO =  info_Mapper.gameview(game_code);
		return info_VO;
	}
	
	@Override
	public List<Info_VO> gamesearch(String searchValue, String genre) throws DataAccessException {
		List<Info_VO> searchGameList;
		searchGameList = info_Mapper.gamesearch(searchValue, genre);
		return searchGameList;
	}
}