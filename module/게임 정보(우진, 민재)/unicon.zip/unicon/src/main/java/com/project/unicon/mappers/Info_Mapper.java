package com.project.unicon.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import com.project.unicon.vo.Info_VO;

public interface Info_Mapper {
	//	모든 게임 리스트 출력
	List<Info_VO> allgamelist() throws DataAccessException;
	
	//	PC게임 리스트 출력
	List<Info_VO> pcgamelist() throws DataAccessException;
	
	//	Mobile게임 리스트 출력
	List<Info_VO> mobilegamelist() throws DataAccessException;
	
	//	Xbox게임 리스트 출력
	List<Info_VO> xboxgamelist() throws DataAccessException;
	
	//	PS게임 리스트 출력
	List<Info_VO> psgamelist() throws DataAccessException;
	
	//	Nintendo게임 리스트 출력
	List<Info_VO> nintendogamelist() throws DataAccessException;
	
	//	게임 검색 기능
	List<Info_VO> gamesearch(@Param("searchValue") String searchValue, @Param("genre") String genre) throws DataAccessException;
	
	//	게임 상세보기
	Info_VO gameview(int game_code) throws DataAccessException;
}