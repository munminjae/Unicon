package com.project.unicon.info.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

public interface Info_Controller {
	public ModelAndView gamelist(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView pcgamelist(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView mobilegamelist(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView xboxgamelist(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView psgamelist(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView nintendogamelist(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView gameview(@RequestParam("game_code") int game_code, HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView gamesearch(@RequestParam(value="searchValue", required=false) String searchValue, 
		@RequestParam(value="genre", required=false) String genre, HttpServletRequest request, HttpServletResponse response) throws Exception;
}