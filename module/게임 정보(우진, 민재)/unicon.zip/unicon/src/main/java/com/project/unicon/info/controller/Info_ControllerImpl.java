package com.project.unicon.info.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.unicon.info.service.Info_Service;
import com.project.unicon.vo.Info_VO;

@Controller("info_Controller")
public class Info_ControllerImpl implements Info_Controller {
	
	@Autowired
	private Info_Service info_Service;
	
	//	모든 게임 리스트 출력
	@Override
	@RequestMapping(value = "/info/gamelist.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView gamelist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		List<Info_VO> gameList = info_Service.gameList();
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("gameList", gameList);
		return mav;
	}
	
	
	//	PC게임 리스트 출력
	@Override
	@RequestMapping(value = "/info/pcgamelist.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView pcgamelist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		List<Info_VO> pcgameList = info_Service.pcgameList();
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("pcgameList", pcgameList);
		return mav;
	}
	
	//	Mobile게임 리스트 출력
	@Override
	@RequestMapping(value = "/info/mobilegamelist.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView mobilegamelist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		List<Info_VO> mobilegameList = info_Service.mobilegameList();
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("mobilegameList", mobilegameList);
		return mav;
	}
	
	//	Xbox게임 리스트 출력
	@Override
	@RequestMapping(value = "/info/xboxgamelist.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView xboxgamelist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		List<Info_VO> xboxgameList = info_Service.xboxgameList();
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("xboxgameList", xboxgameList);
		return mav;
	}
	
	//	PS게임 리스트 출력
	@Override
	@RequestMapping(value = "/info/psgamelist.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView psgamelist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		List<Info_VO> psgameList = info_Service.psgameList();
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("psgameList", psgameList);
		return mav;
	}
	
	//	Nintendo게임 리스트 출력
	@Override
	@RequestMapping(value = "/info/nintendogamelist.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView nintendogamelist(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		List<Info_VO> nintendogameList = info_Service.nintendogameList();
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("nintendogameList", nintendogameList);
		return mav;
	}
	
	//	게임 상세보기
	@Override
	@RequestMapping(value = "/info/gameview", method = { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView gameview(@RequestParam("game_code") int game_code, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		Info_VO info_VO = info_Service.gameview(game_code);
		ModelAndView mav = new ModelAndView(viewName);
		mav.addObject("info_VO", info_VO);
		return mav;
	}
	
	//	게임 검색 기능
	@Override
	@RequestMapping(value = "/info/gamesearch.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView gamesearch(@RequestParam(value="searchValue", required=false) String searchValue,
			@RequestParam(value="genre", required=false) String genre, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String viewName = getViewName(request);
		ModelAndView mav = new ModelAndView(viewName);
		if(genre.equals("all")) {
			System.out.println(genre);
			System.out.println("1");
			List<Info_VO> gameList = info_Service.gamesearch(searchValue, genre);
			System.out.println("2");
			System.out.println("3");
			mav.addObject("gameList", gameList);
			System.out.println("전체 검색");
			mav.setViewName("info/gamelist");
		}
		else if(genre.equals("mobile")) {
			System.out.println(genre);
			System.out.println("1");
			List<Info_VO> gameList = info_Service.gamesearch(searchValue, genre);
			System.out.println("2");
			System.out.println("3");
			mav.addObject("mobilegameList", gameList);
			System.out.println("모바일 검색");
			mav.setViewName("info/mobilegamelist");
		}
		else if(genre.equals("pc")) {
			System.out.println(genre);
			System.out.println("1");
			List<Info_VO> gameList = info_Service.gamesearch(searchValue, genre);
			System.out.println("2");
			System.out.println("3");
			mav.addObject("pcgameList", gameList);
			System.out.println("피씨 검색");
			mav.setViewName("info/pcgamelist");
		}
		else if(genre.equals("switch")) {
			System.out.println(genre);
			System.out.println("1");
			List<Info_VO> gameList = info_Service.gamesearch(searchValue, genre);
			System.out.println("2");
			System.out.println("3");
			mav.addObject("nintendogameList", gameList);
			System.out.println("닌텐도 검색");
			mav.setViewName("info/nintendogamelist");
		}
		else if(genre.equals("ps4")) {
			System.out.println(genre);
			System.out.println("1");
			List<Info_VO> gameList = info_Service.gamesearch(searchValue, genre);
			System.out.println("2");
			System.out.println("3");
			mav.addObject("psgameList", gameList);
			System.out.println("ps4 검색");
			mav.setViewName("info/psgamelist");
		}
		else if(genre.equals("xbox")) {
			System.out.println(genre);
			System.out.println("1");
			List<Info_VO> gameList = info_Service.gamesearch(searchValue, genre);
			System.out.println("2");
			System.out.println("3");
			mav.addObject("xboxgameList", gameList);
			System.out.println("xbox 검색");
			mav.setViewName("info/xboxgamelist");
		}
		
		return mav;
	}
	
	//	View 이름 가져오기
	private String getViewName(HttpServletRequest request) throws Exception {
		String contextPath = request.getContextPath();
		String uri = (String) request.getAttribute("javax.servlet.include.request_uri");
		if (uri == null || uri.trim().equals("")) {
			uri = request.getRequestURI();
		}

		int begin = 0;
		if (!((contextPath == null) || ("".equals(contextPath)))) {
			begin = contextPath.length();
		}

		int end;
		if (uri.indexOf(";") != -1) {
			end = uri.indexOf(";");
		} else if (uri.indexOf("?") != -1) {
			end = uri.indexOf("?");
		} else {
			end = uri.length();
		}

		// System.out.println("begin:"+begin);
		// System.out.println("end:"+end);
		String viewName = uri.substring(begin, end);
		if (viewName.indexOf(".") != -1) {
			viewName = viewName.substring(0, viewName.lastIndexOf("."));
		}
		if (viewName.lastIndexOf("/") != -1) {
			// viewName = viewName.substring(viewName.lastIndexOf("/"), viewName.length());
			viewName = viewName.substring(viewName.lastIndexOf("/", 1), viewName.length());
		}
		return viewName;
	}
}