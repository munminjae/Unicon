package com.project.unicon.vo;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Component("info_VO")
public class Info_VO {
	private String game_code;
	private String game_name;
	private String big_category;
	private String small_category;
	private String genre;
	private Timestamp release_date;
	private String price;
	private String age;
	private String min_system;
	private String recommen_system;
	private Timestamp registered_date;
	private String menufacture;
	private String share_company;
	private String content;
	private String link_1;
	private String link_2;
	private String link_3;
	private String link_4;
	private String hash_tag;
	private String hash_tag2;
	private String hash_tag3;
	
	public Info_VO(String game_code, String game_name, String big_category, String small_category, String genre,
			Timestamp release_date, String price, String age, String min_system, String recommen_system,
			Timestamp registered_date, String menufacture, String share_company, String content, String link_1,
			String link_2, String link_3, String link_4, String hash_tag, String hash_tag2, String hash_tag3) {
		super();
		this.game_code = game_code;
		this.game_name = game_name;
		this.big_category = big_category;
		this.small_category = small_category;
		this.genre = genre;
		this.release_date = release_date;
		this.price = price;
		this.age = age;
		this.min_system = min_system;
		this.recommen_system = recommen_system;
		this.registered_date = registered_date;
		this.menufacture = menufacture;
		this.share_company = share_company;
		this.content = content;
		this.link_1 = link_1;
		this.link_2 = link_2;
		this.link_3 = link_3;
		this.link_4 = link_4;
		this.hash_tag = hash_tag;
		this.hash_tag2 = hash_tag2;
		this.hash_tag3 = hash_tag3;
	}

	public Info_VO() {
		
	}	
}