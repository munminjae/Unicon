package config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import common.intercepter.LogInterceptor;

@Configuration
public class LogInterceptorConfig {
	
	public WebMvcConfigurer LogInterceptorConfig() {
		return new WebMvcConfigurer() {
			@Override
			public void addInterceptors(InterceptorRegistry registry) {
				registry.addInterceptor(new LogInterceptor())
				.addPathPatterns("/info/*.do")
				.addPathPatterns("/*/*.do");
			}
		};
	}
}
