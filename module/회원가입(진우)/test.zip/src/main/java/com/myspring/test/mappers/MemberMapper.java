package com.myspring.test.mappers;

import org.apache.ibatis.annotations.Mapper;

import com.myspring.test.member.MemberVO;

@Mapper
public interface MemberMapper {
	public MemberVO loginById(MemberVO member) throws Exception;
	
	public void insertMember(MemberVO member) throws Exception;

	public int selectOverlappedID(String id) throws Exception;
	
	public int selectOverlappedNCIKNAME(String nickname) throws Exception;
	
	public int selectOverlappedEMAIL(String email) throws Exception;

	public int selectOverlappedPHONE(String phone_number) throws Exception;

	public String findid(MemberVO member);
}
