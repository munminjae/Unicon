package com.myspring.test.member;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller("memberController")
@RequestMapping(value = "/member")
public class MemberControllerImpl implements MemberController{
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	MemberVO memberVO;
	
	//로그인하고 받아서 메인으로가는 메소드
	@Override
	@RequestMapping(value = "/main.do", method = RequestMethod.GET)
	public String main(Locale locale, Model model) {
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "/member/main";
	}
	
	//로그인 하는 메소드
	@Override
	@RequestMapping(value = "/login.do", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView login(@ModelAttribute("loginById") MemberVO member, RedirectAttributes redirect_rAttr, HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		memberVO = memberService.login(member);
		System.out.println(memberVO);
		if(memberVO!=null) {
			session.setAttribute("member", memberVO);
			session.setAttribute("isLogOn", true);
			
			String action = (String) session.getAttribute("action");
			System.out.println("action"+action);
			session.removeAttribute("action");
			mav.setViewName("redirect:/member/main.do");
		}else {
			redirect_rAttr.addAttribute("isLogOn", false);
			mav.setViewName("redirect:/member/loginForm.do");
		}
		return mav;
	}
	//로그아웃 메소드
	@Override
	@RequestMapping(value = "/logout.do", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse sponse) throws Exception {
		HttpSession session = request.getSession();
		session.removeAttribute("member");
		session.removeAttribute("isLogOn");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/member/loginForm.do");
		return mav;
	}
	
	@Override
	@RequestMapping(value="/loginForm.do", method = RequestMethod.GET)
	public String loginform(HttpServletRequest request) throws Exception{
		
		return "/member/loginForm";
	}
	
	@Override
	@RequestMapping(value="/memForm.do", method = RequestMethod.GET)
	public String memberform(HttpServletRequest request) throws Exception{
		
		return "/member/memForm";
	}
	
	//회원가입
	@Override
	@RequestMapping(value="/addMember.do", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView addMember(@ModelAttribute("member") MemberVO member, 
									HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("member: "+member);
		
		String email1 = request.getParameter("email");
		String email2 = request.getParameter("email_add2");
		member.setEmail(email1+"@"+email2);
		
		String phone_number2 = request.getParameter("phone_number2");
		String phone_number3 = request.getParameter("phone_number3");
		member.setPhone_number("010"+phone_number2+phone_number3);
		memberService.addMember(member);
		
		ModelAndView mav = new ModelAndView("member/loginForm");
		mav.addObject("result","addMem");
		

		return mav;
	}
	//아이디 중복체크
	@Override
	@RequestMapping(value="/overlapped.do" ,method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String overlapped(@ModelAttribute("vo") MemberVO member,Model model) throws Exception{
		System.out.println("id:"+member.getId());
		int result = memberService.overlapped(member.getId());
		System.out.println("result: "+result);
		return String.valueOf(result);
	}
	//닉네임 중복체크
	@Override
	@RequestMapping(value="/overlappednick.do" ,method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String overlappednick(@ModelAttribute("vo") MemberVO member,Model model) throws Exception{
		System.out.println("ncikname:"+member.getNickname());
		int result = memberService.overlappednick(member.getNickname());
		System.out.println("result: "+result);
		return String.valueOf(result);
	}
	//이메일 중복체크
	@Override
	@RequestMapping(value="/overlappedemail.do" ,method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String overlappedemail(@ModelAttribute("vo") MemberVO member,Model model) throws Exception{
		System.out.println("email:"+member.getEmail());
		int result = memberService.overlappedemail(member.getEmail());
		System.out.println("result: "+result);
		return String.valueOf(result);
	}
	//전화번호 중복체크
	@Override
	@RequestMapping(value="/overlappedphone.do" ,method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String overlappedphone(@ModelAttribute("vo") MemberVO member,Model model) throws Exception{
		System.out.println("phone_number:"+member.getPhone_number());
		int result = memberService.overlappedphone(member.getPhone_number());
		System.out.println("result: "+result);
		return String.valueOf(result);
	}
	
	//아이디찾기
	@Override
	@RequestMapping(value="/idfind.do" ,method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView findid(@ModelAttribute("member") MemberVO member,RedirectAttributes redirect_rAttr, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String email1 = request.getParameter("email");
		String email2 = request.getParameter("email_add2");
		member.setEmail(email1+"@"+email2);
		HttpSession session = request.getSession();
		
		String id = memberService.findid(member);
		ModelAndView mav = new ModelAndView("member/idfindForm");
		mav.addObject("id",id);
		if(id != null) {
			session.setAttribute("id", id);
			String action = (String) session.getAttribute("action");
			System.out.println("action"+action);
			session.removeAttribute("action");
			mav.setViewName("redirect:/member/main.do");
		}else {
			redirect_rAttr.addAttribute("isLogOn", false);
			mav.setViewName("redirect:/member/infind.do");
		}
		return mav;
	}
	
	@Override
	@RequestMapping(value="/idfindForm.do", method = RequestMethod.GET)
	public String idfindform(HttpServletRequest request) throws Exception{
		
		return "/member/idfindForm";
}

}