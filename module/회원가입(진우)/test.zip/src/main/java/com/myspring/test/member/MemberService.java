package com.myspring.test.member;



public interface MemberService {
	public MemberVO login(MemberVO member) throws Exception;
	
	public void addMember(MemberVO member) throws  Exception;

	public int overlapped(String id) throws Exception;
	
	public int overlappednick(String nickname) throws Exception;
	
	public int overlappedemail(String email) throws Exception;
	
	public int overlappedphone(String phone_number) throws Exception;

	public String findid(MemberVO member) throws Exception;

}