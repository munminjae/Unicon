package com.myspring.test.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.myspring.test.mappers.MemberMapper;

@Service("memberService")
@Transactional(propagation = Propagation.REQUIRED)
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Override
	public MemberVO login(MemberVO member) throws Exception {
		System.out.println("ser: "+member);
		return memberMapper.loginById(member);
	}
	
	@Override
	public void addMember(MemberVO member) throws  Exception {
		memberMapper.insertMember(member);
	}
	
	@Override
	public int overlapped(String id) throws Exception{
		System.out.println("ser id: "+id);
		return memberMapper.selectOverlappedID(id);
		
	}
	@Override
	public int overlappednick(String nickname) throws Exception{
		System.out.println("ser nickname: "+nickname);
		return memberMapper.selectOverlappedNCIKNAME(nickname);
		
	}
	@Override
	public int overlappedemail(String email) throws Exception{
		System.out.println("ser email: "+email);
		return memberMapper.selectOverlappedEMAIL(email);
		
	}
	@Override
	public int overlappedphone(String phone_number) throws Exception{
		System.out.println("ser phone_number: "+phone_number);
		return memberMapper.selectOverlappedPHONE(phone_number);
		
	}
	
	@Override
	public String findid(MemberVO member) throws Exception{
		System.out.println("ser member: " + member);
		return memberMapper.findid(member);
	}
}
