package com.myspring.test.member;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component("memberVO")
@Getter
@Setter
public class MemberVO {
	private String id;
	private String password;
	private String nickname;
	private String phone_number;
	private String email;
	private Timestamp join_date;
	private String del_date;
	private int grade;
	private String name;
	private String birthday;
	private String sex;

}
